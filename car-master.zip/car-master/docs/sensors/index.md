---
title: "Sensors"
---

Sensors are tools that collect data that can be used to run analytics.

CAR currently has a limited number of sensors mapped to the CAR [Data Model](../data_model). They are:
* [auditd (2.8)](auditd_2.8)
* [Autoruns (13.98)](autoruns_13.98)
* [osquery (4.1.2)](osquery_4.1.2)
* [osquery (4.6.0)](osquery_4.6.0)
* [Sysmon (10.4)](sysmon_10.4)
* [Sysmon (11.0)](sysmon_11.0)
* [Sysmon (13)](sysmon_13)