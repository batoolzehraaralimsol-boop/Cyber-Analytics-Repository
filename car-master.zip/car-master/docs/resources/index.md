---
title: Resources
---
##Updates 
[New Updates Found Here](/updates/index.md)

##Glossary
[Definitions Found Here](/glossary/index.md)
