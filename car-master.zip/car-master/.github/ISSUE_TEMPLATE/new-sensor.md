---
name: New Sensor
about: Add a new sensor

---

## *Sensor Name*

*Describe the sensor here, including a link to its homepage. Note that only sensor mappings for built-in utilities or open source tools are accepted in CAR.*

### Mapping

*Describe the sensor's coverage in CAR. Copy and paste the text below as many times as necessary for each object. Pre-built tables for each object can be found in the existing sensors.*

### object1

| | `field1` | `field2` | `field3`
|---|---|---|---|
| `action1` | |✓|✓ |
| `action2` |✓ | | |
