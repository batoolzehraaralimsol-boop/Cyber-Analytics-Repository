---
name: Data Model Change
about: For proposing a new object, action, or field to the CAR data model

---

## *Proposed Change*

*Explain your proposed change. Preferably, copy the markdown text from `docs/data_model` and paste the updated markdown here.*

### Justification

*Link to or copy an analytic that you have that requires this change.*
